import boto3
import os
import json

sqs = boto3.client('sqs')
s3 = boto3.client('s3')

SQS_QUEUE_URL = os.environ['SQS_QUEUE_URL']
S3_BUCKET_NAME = "pgr301-couch-explorers"

def lambda_handler(event, context):
    for record in event['Records']:
        message_body = json.loads(record['body'])
        file_content = generate_image(message_body)  # Placeholder for image generation
        s3.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=f"{message_body['filename']}.png",
            Body=file_content
        )
        sqs.delete_message(
            QueueUrl=SQS_QUEUE_URL,
            ReceiptHandle=record['receiptHandle']
        )
    return {"statusCode": 200, "body": "Processed"}

def generate_image(data):
    return b"This is a placeholder for an image file"
