package com.example;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class ImageGenerator {

    public static void main(String[] args) {
        // Call the image generation method
        System.setProperty("java.awt.headless", "true");
        generateImage();
    }

    // Simple method to generate an image and display it
    private static void generateImage() {
        // Create a BufferedImage object to represent an image
        int width = 400, height = 400;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        // Fill the image with a simple color (Red background)
        Graphics2D g2d = image.createGraphics();
        g2d.setColor(Color.RED);
        g2d.fillRect(0, 0, width, height);
        g2d.dispose();

        // Display the generated image using a JFrame
        JFrame frame = new JFrame("Generated Image");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(width, height);
        frame.add(new JLabel(new ImageIcon(image)));
        frame.setVisible(true);

        System.out.println("Image generated and displayed.");
    }
}
